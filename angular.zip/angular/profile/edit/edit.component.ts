import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormControl } from '@angular/forms';
import {ProfileService } from './../profile.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

 
  constructor(private fb: FormBuilder, private service: ProfileService,private activeRoute: ActivatedRoute) { }
  response : object;
  isError : boolean = true; 
  
  private base64textString:String="";
  entryRes : any;
  jobProfiles = ['Developer', 'Manager',
            'HR', 'Accounts'];
    
    profileForm = this.fb.group({
      FullName: ["", Validators.required],
      address: ['', Validators.required],
      jobProfile : [this.jobProfiles, Validators.required],
      //profilePic:['' , Validators.required],
      encSrc : [""],
      id : [""]
       
    });
    //encSrc = new FormControl('');
    onSubmit = function(){  
      this.submitProfile(this.profileForm.value);     
    }
    submitProfile(formData){
      
      this.service.updateProfile(formData)
      .subscribe(data => {   
        this.isError =  false;     
          this.response = data;
      },error => {
          this.isError =  true;
          this.response = {};
      })
  
    }

   
  
    handleFileUpload(evt){
        var files = evt.target.files;
        var file = files[0];
      
      if (files && file) {
          var reader = new FileReader();
  
          reader.onload =this._handleReaderLoaded.bind(this);        
          reader.readAsBinaryString(file);
         
      }
      
      
    }
    
    _handleReaderLoaded(readerEvt) {
      var binaryString = readerEvt.target.result;
      this.base64textString = btoa(binaryString);  
      this.profileForm.patchValue({
          encSrc: this.base64textString
        });   
                 
      }

  ngOnInit() {
    const routeParams = this.activeRoute.snapshot.params;
    this.getProfileById(routeParams.id);
  }
  getProfileById(id){
    this.service.getProfileById(id)
    .subscribe(data => {   
      
      this.profileForm.patchValue({
        FullName: data['FullName'],
        address:  data['address'],
        jobProfile : data['jobProfile'],
        encSrc : data['profilePic'],
        id : data['id']
        
      });
     // this.base64textString = data['profilePic']; 
    },error => {
    
        this.response = {};
    })
  }

}
