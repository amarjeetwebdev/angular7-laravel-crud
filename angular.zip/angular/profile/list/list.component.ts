import { Component, OnInit } from '@angular/core';
import {ProfileService } from './../profile.service';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

 
  constructor(private service: ProfileService,) { }
  response : object;
     
    ngOnInit() {
      this.getProfiles();
    }
    /**
     * Method to get data list
     * @output object
     */
    getProfiles(){
      this.service.getProfile()
      .subscribe(data => {   
      
          this.response = data;
      },error => {
      
          this.response = {};
      })
    }

    /**
     * method to remove item from list
     * @var profile id
     * @output object response
     */
    deleteProfile(id){
      this.service.removeProfile(id)
      .subscribe(data => {         
        this.getProfiles();
      },error => {
        this.getProfiles();
      })
    }

}
