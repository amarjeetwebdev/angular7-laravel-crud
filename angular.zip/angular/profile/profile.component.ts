import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormControl } from '@angular/forms';
import {ProfileService } from './profile.service';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private fb: FormBuilder, private service: ProfileService,) { }
  response : object;
  isError : boolean = true;
  showImg : boolean = false;
  private base64textString:String="";
  entryRes : any;
  jobProfiles = ['Developer', 'Manager',
            'HR', 'Accounts'];

    profileForm = this.fb.group({
      FullName: ['', Validators.required],
      address: ['', Validators.required],
      jobProfile : [this.jobProfiles, Validators.required],
      profilePic:['' , Validators.required],
      encSrc : [this.base64textString]
       
    });
    //encSrc = new FormControl('');
    onSubmit = function(){
      
     // this.profileForm.encSrc = this.base64textString;
      
      this.submitProfile(this.profileForm.value);     
    }
    submitProfile(formData){
      
      this.service.saveProfile(formData)
      .subscribe(data => {   
        this.isError =  false;     
          this.response = data;
      },error => {
          this.isError =  true;
          this.response = {};
      })
  
    }

   
  
    handleFileUpload(evt){
        var files = evt.target.files;
        var file = files[0];
      
      if (files && file) {
          var reader = new FileReader();
  
          reader.onload =this._handleReaderLoaded.bind(this);        
          reader.readAsBinaryString(file);
          this.showImg = true;
      }
      
      
    }
    
    _handleReaderLoaded(readerEvt) {
      var binaryString = readerEvt.target.result;
      this.base64textString = btoa(binaryString);  
      this.profileForm.patchValue({
          encSrc: this.base64textString
      });   
                 
      }

    ngOnInit() {
    
    }

}
