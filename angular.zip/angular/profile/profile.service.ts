import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { environment } from './../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor( private http: HttpClient   ) { }
  saveProfile (formData){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':'application/json',        
        'Authorization' : 'BIpAlWn88ippuziveMP0zRIy5cO9i92XR2aTQTYgL1c='
      })
    };
     return this.http.post(environment.APIURL+"/profile", formData, httpOptions)
  }

  /**
   * Method to update the profile
   * @var object input
   * @return boolean
   */
  updateProfile(formData){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':'application/json',        
        'Authorization' : 'BIpAlWn88ippuziveMP0zRIy5cO9i92XR2aTQTYgL1c='
      })
    };
     return this.http.put(environment.APIURL+"/profile/"+formData['id'], formData, httpOptions)
  }

  /**
   *  @Method to get the profile list 
   *  @output object
   */
  getProfile(){
    return this.http.get(environment.APIURL+"/profile");
  }
  /**
   * 
   * 
   */
  getProfileById(id){
    return this.http.get(environment.APIURL+"/profile/"+id);
  }

  /**
   * Method to remove from profile
   * @return json data after removal
   */
  removeProfile(id){
    return this.http.delete(environment.APIURL+"/profile/"+id);
  }

}
