import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppLayoutComponent } from './_layouts/app-layout/app-layout.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register';
import { AuthGuard } from './_guards';
import { ProfileComponent } from './profile/profile.component';
import { ListComponent } from './profile/list/list.component';
import { EditComponent } from './profile/edit/edit.component';


const routes: Routes = [
  {
    path: 'index',
    component: AppLayoutComponent, 
    canActivate: [AuthGuard],
    children: [
      { 
        path: 'home',
        loadChildren: './home/home.module#HomeModule'
      }, 
    ],
  },
  //{ path: '', component: HomeComponent, canActivate: [AuthGuard] },
  //{ path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'profile/list', component: ListComponent },
  { path: 'profile/:id/edit', component: EditComponent },
  

  // otherwise redirect to home
  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }