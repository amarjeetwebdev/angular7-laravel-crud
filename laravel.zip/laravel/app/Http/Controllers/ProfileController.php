<?php

namespace App\Http\Controllers;
use App\Profile;
use Validator;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = Profile::all();
        return response()->json($users, 200);
    } 
    /**
     * Show profile by id
     * @return response object
     */
    public function show($id)
    {
        $users =  Profile::findOrFail($id);
        return response()->json($users, 200);
    } 
    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'FullName' => 'required|max:255',
            'address' => 'required',
            'jobProfile' => 'required',
            'profilePic' => 'required',
        ]);
        
        if ($validator->fails()) {
            return response()->json(['error' => true, 'status' => 'failed', 'message' => 'required mandatory fields']);
        }else{
            $request->all()['profilePic'] = $request->encSrc;
            unset($request->encSrc);
         
            $flight = Profile::create([
                'FullName' => $request->FullName,
                'address' => $request->FullName,
                'jobProfile' => $request->jobProfile,
                'profilePic' => $request->encSrc
            ]);
            return response()->json(['error' => false, 'status' => 'OK', 'message' => 'Record has been successfully created']);
        }
        
    }

   
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'FullName' => 'required|max:255',
            'address' => 'required',
            'jobProfile' => 'required'
        ]);
        
        if ($validator->fails()) {
            return response()->json(['error' => true, 'status' => 'failed', 'message' => 'required mandatory fields']);
        }else{
            
            Profile::where('id', $id)
          ->update([
              'FullName' => $request->FullName,
              'address' => $request->FullName,
              'jobProfile' => $request->jobProfile,
              'profilePic' => $request->encSrc
            ]);
            return response()->json(['error' => false, 'status' => 'OK', 'message' => 'Record has been successfully updated']);
        }

       

        //$flight = Profile::update($request->all());
        return response()->json(['status' => 'OK']);
       
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
        Profile::where('id', $id)->delete();
        return response()->json(['error' => false, 'status' => 'OK', 'message' => 'Record has been Successfully Deleted']);
    }
}
